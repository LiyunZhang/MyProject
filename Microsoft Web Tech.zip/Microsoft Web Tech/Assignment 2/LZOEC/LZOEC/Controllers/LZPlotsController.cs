﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using LZOEC.Models;
using Microsoft.AspNetCore.Http;

namespace LZOEC.Controllers
{
    public class LZPlotsController : Controller
    {
        private readonly OECContext _context;

        public LZPlotsController(OECContext context)
        {
            _context = context;
        }

        // GET: LZPlots
        public async Task<IActionResult> Index(int CropId, string Name, string order)
        {
            //Session for Plot
            HttpContext.Session.SetString("CropId", CropId.ToString());


            var oECContext = _context.Plot.Include(p => p.Farm).Include(p => p.Variety).Include(p => p.Treatment).Include(p => p.Variety.Crop).OrderByDescending(item => item.DatePlanted);
                    var outPut = await oECContext.ToListAsync();
        // SHOW all plots 
            if(CropId == 0)
            {
                     outPut = await oECContext.ToListAsync();
            }
            else if (CropId == 1)
            {
                outPut = await oECContext.ToListAsync();
            }
            else
            {
                var OECContext = _context.Plot.Include(p => p.Farm).Include(p => p.Variety).Include(p => p.Treatment).Include(p => p.Variety.Crop).Where(p => p.VarietyId.Equals(CropId));

                 outPut = await OECContext.ToListAsync();
            }

            //Reorder the listing by Click the headings
            if(order == "FarmName")
            {
                outPut = await oECContext.OrderBy(p => p.Farm.Name).ToListAsync();

            }
            else if(order == "VarietyName")
            {
                outPut = await oECContext.OrderBy(p => p.Variety.Name).ToListAsync();
            }
            else if (order == "CEC")
            {
                outPut = await oECContext.OrderBy(p => p.Cec).ToListAsync();
            }
           
            return View(outPut);
        }

        // GET: LZPlots/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var plot = await _context.Plot
                .Include(p => p.Farm)
                .Include(p => p.Variety)
                .SingleOrDefaultAsync(m => m.PlotId == id);
            if (plot == null)
            {
                return NotFound();
            }

           
            return View(plot);
        }


        // GET: LZPlots/Create
        public IActionResult Create()
        {
            //Get Session
            int Id = int.Parse(HttpContext.Session.GetString("CropId"));

            ViewData["FarmId"] = new SelectList(_context.Farm.OrderBy(p => p.Name), "FarmId", "Name");
            ViewData["VarietyId"] = new SelectList(_context.Variety.OrderBy(p => p.Name), "VarietyId", "Name", Id);            
            return View();
        }

        // POST: LZPlots/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PlotId,FarmId,VarietyId,DatePlanted,DateHarvested,PlantingRate,PlantingRateByPounds,RowWidth,PatternRepeats,OrganicMatter,BicarbP,Potassium,Magnesium,Calcium,PHsoil,PHbuffer,Cec,PercentBaseSaturationK,PercentBaseSaturationMg,PercentBaseSaturationCa,PercentBaseSaturationH,Comments")] Plot plot)
        {
            if (ModelState.IsValid)
            {
                _context.Add(plot);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["FarmId"] = new SelectList(_context.Farm, "FarmId", "Name", plot.FarmId);
            ViewData["VarietyId"] = new SelectList(_context.Variety, "VarietyId", "Name", plot.VarietyId);
            return View(plot);
        }

        // GET: LZPlots/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var plot = await _context.Plot.SingleOrDefaultAsync(m => m.PlotId == id);
            if (plot == null)
            {
                return NotFound();
            }
            ViewData["FarmId"] = new SelectList(_context.Farm.OrderBy(p => p.Name), "FarmId", "Name", plot.FarmId);
            ViewData["VarietyId"] = new SelectList(_context.Variety.OrderBy(p => p.Name), "VarietyId", "Name", plot.VarietyId);
            return View(plot);
        }

        // POST: LZPlots/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PlotId,FarmId,VarietyId,DatePlanted,DateHarvested,PlantingRate,PlantingRateByPounds,RowWidth,PatternRepeats,OrganicMatter,BicarbP,Potassium,Magnesium,Calcium,PHsoil,PHbuffer,Cec,PercentBaseSaturationK,PercentBaseSaturationMg,PercentBaseSaturationCa,PercentBaseSaturationH,Comments")] Plot plot)
        {
            if (id != plot.PlotId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(plot);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PlotExists(plot.PlotId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["FarmId"] = new SelectList(_context.Farm, "FarmId", "ProvinceCode", plot.FarmId);
            ViewData["VarietyId"] = new SelectList(_context.Variety, "VarietyId", "VarietyId", plot.VarietyId);
            return View(plot);
        }

        // GET: LZPlots/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var plot = await _context.Plot
                .Include(p => p.Farm)
                .Include(p => p.Variety)
                .SingleOrDefaultAsync(m => m.PlotId == id);
            if (plot == null)
            {
                return NotFound();
            }

            return View(plot);
        }

        // POST: LZPlots/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var plot = await _context.Plot.SingleOrDefaultAsync(m => m.PlotId == id);
            _context.Plot.Remove(plot);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PlotExists(int id)
        {
            return _context.Plot.Any(e => e.PlotId == id);
        }
    }
}
