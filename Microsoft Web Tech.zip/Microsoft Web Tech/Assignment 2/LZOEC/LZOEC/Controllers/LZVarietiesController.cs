﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using LZOEC.Models;
using Microsoft.AspNetCore.Http; // required for GetString() & SetString()

namespace LZOEC.Controllers
{
    public class LZVarietiesController : Controller
    {
        private readonly OECContext _context;

        public LZVarietiesController(OECContext context)
        {
            _context = context;
        }

        // GET: LZVarieties
        public async Task<IActionResult> Index(string CropId, string Name)
        {
            // create or change session variables
            if (!String.IsNullOrEmpty(CropId) && !String.IsNullOrEmpty(Name))
            {
                // session
                HttpContext.Session.SetString("CropId", CropId);
                HttpContext.Session.SetString("Name", Name);
            }

            else if (!string.IsNullOrEmpty(HttpContext.Session.GetString("CropId")) && !string.IsNullOrEmpty(HttpContext.Session.GetString("Name")))
            {
                string missingCrop = "Please select a crop to see its varieties";
                TempData["message"] = missingCrop;

                return RedirectToAction("Index", "LZCrop");
            }

            //var variety = await _context.Variety.Include(v => v.Crop).Where(x => x.CropId == int.Parse(CropId)).OrderBy(x => x.Name).ToListAsync();
            //return View(variety);

            ViewBag.headingtitle = "Varieties of " + HttpContext.Session.GetString("Name");
            var oECContext = _context.Variety.Include(v => v.Crop).Where(v => v.CropId.ToString() == CropId);
            return View(await oECContext.ToListAsync());
           

        }

        // GET: LZVarieties/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var variety = await _context.Variety
                .Include(v => v.Crop)
                .SingleOrDefaultAsync(m => m.VarietyId == id);
            if (variety == null)
            {
                return NotFound();
            }
            string cropid = ViewBag.CookiesFirstName = HttpContext.Session.GetString("CropId");
            ViewBag.HiddenCropId = cropid;
            ViewBag.headingtitle = "Details of " + HttpContext.Session.GetString("Name") + " variety";
            return View(variety);
        }

        // GET: LZVarieties/Create
        public IActionResult Create()
        {
            //ViewData["CropId"] = new SelectList(_context.Crop, "CropId", "CropId");
            //return View();

            string cropid = ViewBag.CookiesFirstName = HttpContext.Session.GetString("CropId");
            ViewBag.HiddenCropId = cropid;
            ViewBag.headingtitle = "Add a " + HttpContext.Session.GetString("Name") + " variety";
            ViewData["CropId"] = new SelectList(_context.Crop, "CropId", "CropId");
            return View();
        }

        // POST: LZVarieties/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("VarietyId,CropId,Name")] Variety variety)
        {
            if (ModelState.IsValid)
            {
                string cropid = HttpContext.Session.GetString("CropId");
                variety.CropId = Convert.ToInt16(cropid);
                _context.Add(variety);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["CropId"] = new SelectList(_context.Crop, "CropId", "CropId", variety.CropId);
            return View(variety);
        }

        // GET: LZVarieties/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var variety = await _context.Variety.SingleOrDefaultAsync(m => m.VarietyId == id);
            if (variety == null)
            {
                return NotFound();
            }
            string cropid = ViewBag.CookiesFirstName = HttpContext.Session.GetString("CropId");
            ViewBag.HiddenCropId = cropid;
            ViewBag.headingtitle = "Edit " + HttpContext.Session.GetString("Name") + " variety";
            ViewData["CropId"] = new SelectList(_context.Crop, "CropId", "CropId", variety.CropId);
            return View(variety);
        }

        // POST: LZVarieties/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("VarietyId,CropId,Name")] Variety variety)
        {
            if (id != variety.VarietyId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(variety);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!VarietyExists(variety.VarietyId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CropId"] = new SelectList(_context.Crop, "CropId", "CropId", variety.CropId);
            return View(variety);
        }

        // GET: LZVarieties/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var variety = await _context.Variety
                .Include(v => v.Crop)
                .SingleOrDefaultAsync(m => m.VarietyId == id);
            if (variety == null)
            {
                return NotFound();
            }
            string cropid = ViewBag.CookiesFirstName = HttpContext.Session.GetString("CropId");
            ViewBag.HiddenCropId = cropid;
            ViewBag.headingtitle = "Delete " + HttpContext.Session.GetString("Name") + " variety";
            return View(variety);
        }

        // POST: LZVarieties/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var variety = await _context.Variety.SingleOrDefaultAsync(m => m.VarietyId == id);
            _context.Variety.Remove(variety);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool VarietyExists(int id)
        {
            return _context.Variety.Any(e => e.VarietyId == id);
        }
    }
}
