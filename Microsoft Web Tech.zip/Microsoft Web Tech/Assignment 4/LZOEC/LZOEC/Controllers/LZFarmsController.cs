﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using LZOEC.Models;
using System.Text.RegularExpressions;

namespace LZOEC.Controllers
{
    
    public class LZFarmsController : Controller
    {
        
        private readonly OECContext _context;

        public JsonResult CheckProvinceCode(String provinceCode)
        {
            int countProvinceCode = _context.Province.Count(p => p.Name == provinceCode);

            if (countProvinceCode == 0)
            {
                if (provinceCode.Length != 2 || !Regex.IsMatch(provinceCode, @"^[a-zA-Z]+$"))
                {
                    return Json("Province Code must  be exactly 2 letters long.");
                }

                if (_context.Province.Count(p => p.ProvinceCode == provinceCode) == 0)
                {
                    return Json("Error validating province code");
                }
            }
            else
            {
                return Json(false);
            }
            return Json(true);
        }    
        
      


        public LZFarmsController(OECContext context)
        {
            _context = context;
        }

        // GET: LZFarms
        public async Task<IActionResult> Index()
        {
            var oECContext = _context.Farm.OrderBy(a => a.Name)
                .Include(f => f.ProvinceCodeNavigation);
            return View(await oECContext.ToListAsync());
        }

        // GET: LZFarms/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var farm = await _context.Farm
                .Include(f => f.ProvinceCodeNavigation)
                .SingleOrDefaultAsync(m => m.FarmId == id);
            if (farm == null)
            {
                return NotFound();
            }

            return View(farm);
        }

        // GET: LZFarms/Create
        public IActionResult Create()
        {
            ViewData["ProvinceCode"] = new SelectList(_context.Province, "ProvinceCode", "ProvinceCode");
            return View();
        }

        // POST: LZFarms/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("FarmId,Name,Address,Town,County,ProvinceCode,PostalCode,HomePhone,CellPhone,Email,Directions,DateJoined,LastContactDate")] Farm farm)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _context.Add(farm);
                    await _context.SaveChangesAsync();
                    TempData["Message"] = "You created new Farm data";
                    return RedirectToAction(nameof(Index));
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Error created: {ex.GetBaseException().Message}");
            }
            //ViewData["ProvinceCode"] = new SelectList(_context.Province, "ProvinceCode", "ProvinceCode", farm.ProvinceCode);
            Create();
            return View(farm);
        }

        // GET: LZFarms/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var farm = await _context.Farm.SingleOrDefaultAsync(m => m.FarmId == id);
            if (farm == null)
            {
                return NotFound();
            }
            //ViewData["ProvinceCode"] = new SelectList(_context.Province, "ProvinceCode", "ProvinceCode", farm.ProvinceCode);
            Create();
            return View(farm);
        }

        // POST: LZFarms/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("FarmId,Name,Address,Town,County,ProvinceCode,PostalCode,HomePhone,CellPhone,Email,Directions,DateJoined,LastContactDate")] Farm farm)
        {
            if (id != farm.FarmId)
            {
                //return NotFound();
                ModelState.AddModelError("", " Farm ID is Invalid, please try again");
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(farm);
                    await _context.SaveChangesAsync();
                    TempData["Message"] = "Farm edit success";
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FarmExists(farm.FarmId))
                    {
                        //return NotFound();
                        ModelState.AddModelError("", " Farm doesn't exist");
                    }
                    else
                    {
                        //throw;
                        ModelState.AddModelError("", " The record is same");
                    }
                }
                //return RedirectToAction(nameof(Index));
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $" Error thrown on edit: {ex.GetBaseException().Message}");
                }
            }
            //ViewData["ProvinceCode"] = new SelectList(_context.Province, "ProvinceCode", "ProvinceCode", farm.ProvinceCode);
            Create();
            return View(farm);
        }

        // GET: LZFarms/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var farm = await _context.Farm
                .Include(f => f.ProvinceCodeNavigation)
                .SingleOrDefaultAsync(m => m.FarmId == id);
            if (farm == null)
            {
                return NotFound();
            }

            return View(farm);
        }

        // POST: LZFarms/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                var farm = await _context.Farm.SingleOrDefaultAsync(m => m.FarmId == id);
                _context.Farm.Remove(farm);
                await _context.SaveChangesAsync();
                TempData["Message"] = "The record was deleated";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                TempData["Message"] = $"Error thrown on delete: {ex.GetBaseException().Message}";
            }
            return Redirect($"/farm/delete/{id}");
        }

        private bool FarmExists(int id)
        {
            return _context.Farm.Any(e => e.FarmId == id);
        }
    }
}
