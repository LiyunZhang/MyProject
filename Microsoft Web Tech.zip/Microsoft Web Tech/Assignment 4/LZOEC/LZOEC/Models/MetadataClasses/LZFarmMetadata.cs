﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using LZClassLibrary;
using Microsoft.AspNetCore.Mvc;

namespace LZOEC.Models
{
    [ModelMetadataType(typeof(LZFarmMetadata))]
    public partial class Farm : IValidatableObject
    {
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if(Name != null)
            {
                Name = Name.Trim();
                Name = LZValidations.LZCapitalize(Name);
            }
            if (Address != null)
            {
                Address = Address.Trim();
                Address = LZValidations.LZCapitalize(Address);
            }
            if (Town != null)
            {
                Town = Town.Trim();
                Town = LZValidations.LZCapitalize(Town);
            }
            if (County != null)
            {
                County = County.Trim();
                County = LZValidations.LZCapitalize(County);
            }
            if (ProvinceCode != null)
            {
                ProvinceCode = ProvinceCode.Trim();
                ProvinceCode = ProvinceCode.ToUpper();
            }

            if (Name == null)
            {
                yield return new ValidationResult("Please entry a name",new[] { nameof(Name) });
            }
            if (ProvinceCode == null)
            {
                yield return new ValidationResult("Please entry a Provice", new[] { nameof(ProvinceCode) });
            }
            if (Town == null && County == null)
            {
                yield return new ValidationResult("at least one of Town or Country must be provided", new string[] { "Town", "County" });
            }
            if (Email == null && (Address == null || PostalCode == null))
            {
                yield return new ValidationResult("either Email or both address and Postal Code must be provided", new string[] { "Email", "Address", "PostalCode" });
            }

            if (HomePhone != null)
            {
                HomePhone = HomePhone.Trim();
                string HPhone = HomePhone;
                if (!LZValidations.LZphoneCheck(ref HPhone))
                {
                    yield return new ValidationResult($"Home phone is an incorrect pattern: 123-123-1234", new string[] { nameof(HomePhone) });
                }
                else
                {
                    string number = HomePhone;
                    string a = number.Substring(0, 3);
                    string b = number.Substring(3, 3);
                    string c = number.Substring(6);
                    HomePhone = a + "-" + b + "-" + c;
                }
            }

            if (CellPhone != null)
            {
                CellPhone = CellPhone.Trim();

                string phone = CellPhone;
                if (!LZValidations.LZphoneCheck(ref phone))
                {
                    yield return new ValidationResult($"Cell phone is an incorrect pattern: 123-123-1234", new string[] { nameof(CellPhone) });
                }
                else
                {
                    string number = CellPhone;
                    string a = number.Substring(0, 3);
                    string b = number.Substring(3, 3);
                    string c = number.Substring(6);
                    CellPhone = a + "-" + b + "-" + c;
                }
            }



            yield return ValidationResult.Success;
        }

        public class LZFarmMetadata
        {

            public int FarmId { get; set; }
            
            [Display(Name = "Farm Name")]
            public string Name { get; set; }
            [Display(Name = "Address")]
            public string Address { get; set; }
            [Display(Name = "Town")]
            public string Town { get; set; }
            [Display(Name = "Country")]
            public string County { get; set; }
            
            [Display(Name = "Province")]
            public string ProvinceCode { get; set; }
            [Display(Name = "Postal Code")]
            public string PostalCode { get; set; }
            [Display(Name = "Home Phone")]
            public string HomePhone { get; set; }
            [Display(Name = "Cell phone")]
            public string CellPhone { get; set; }
            [Display(Name = "Email")]
            public string Email { get; set; }
            [Display(Name = "Directions")]
            public string Directions { get; set; }
            [Display(Name = "Date Joined")]
            [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd MMM yyyy}")]
            [LZDateNotInFuture]
            public DateTime? DateJoined { get; set; }
            [Display(Name = "Last Contact")]
            [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd MMM yyyy}")]
            [LZDateNotInFuture]
            public DateTime? LastContactDate { get; set; }
            [Display(Name = "Province")]
            public Province ProvinceCodeNavigation { get; set; }
            public ICollection<Plot> Plot { get; set; }
        }
    }
}
