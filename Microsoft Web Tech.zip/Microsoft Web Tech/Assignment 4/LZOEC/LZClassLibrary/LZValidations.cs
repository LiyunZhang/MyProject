﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Text.RegularExpressions;


namespace LZClassLibrary
{
    public class LZValidations
    {
        public static string LZCapitalize(string name)
        {
            //if input is null
            if(name == null)
            {
                return null;
            }

            //change to lower case and trim spaces           
            
                string tempName = name.ToLower().Trim();
                string[] nameArray = tempName.Split(" ");
                string finalResult = "";

                for(int i=0; i < nameArray.Length; i++)
                {
                    string newName = nameArray[i];
                    finalResult += char.ToUpper(newName[0]) + newName.Substring(1);
                    finalResult = finalResult.Trim();
                }
                
                return finalResult;
        }
        public static bool LZPostalCodeValidation(ref string postalCode)
        {
            Regex pattern = new Regex(@"[ABCEGHJKLMNPRSTVXY]\d[ABCEGHJKLMNPRSTVXY | abceghjklmnprstvwxyz] ?\d[ABCEGHJKLMNPRSTVXY]\d$", RegexOptions.IgnoreCase);

            if (postalCode == null || postalCode.ToString() == "" || pattern.IsMatch(postalCode.ToString()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool LZZipCodeValidation(ref String postalCode)
        {
            string pattern = @"^[0-9]{5}([- /]?[0-9]{4})?$";
            if (postalCode == null || postalCode.ToString() == "" || Regex.Match(postalCode, pattern).Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool LZphoneCheck(ref string num)
        {
            string[] phoneNum = Regex.Split(num, string.Empty);
            int result;
            int count = 0;
            foreach (string a in phoneNum)
            {
                if (int.TryParse(a, out result))
                {
                    count++;
                }
            }

            if (count == 10)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
