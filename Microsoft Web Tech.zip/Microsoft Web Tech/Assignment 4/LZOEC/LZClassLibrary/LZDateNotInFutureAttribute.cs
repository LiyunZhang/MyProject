﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace LZClassLibrary
{
    public class LZDateNotInFutureAttribute : ValidationAttribute
    {
        public LZDateNotInFutureAttribute()
        {
            ErrorMessage = "The date is in future, please choose a correct date";
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == null)
            {
                return ValidationResult.Success;
            }
            DateTime date_time = (DateTime)value;

            
            if (date_time > DateTime.Now)
            {
                return new ValidationResult(string.Format(ErrorMessage, validationContext.DisplayName));
            }

            else
            {
                return ValidationResult.Success;
            }
        }
    }
}
