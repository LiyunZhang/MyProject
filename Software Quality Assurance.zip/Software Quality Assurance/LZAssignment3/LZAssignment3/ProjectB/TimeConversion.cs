﻿/*Program.cs
 *  PROG2070
 *  LZAssignment 3 - Project - TimeConversion.cs 
 *  Liyun Zhang, 2018.03.29: Created
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectB
{
    public static class TimeConversion
    {
        public static double Convert(double value, string unitConvertFrom, string unitConvertTo)
        {

            unitConvertFrom = ModifyInput(unitConvertFrom);
            unitConvertTo = ModifyInput(unitConvertTo);

            Console.WriteLine("\nConvert from: " + unitConvertFrom);
            Console.WriteLine("\nConvert To:" + unitConvertTo);

            //should be called GetMultiplier Method using (unitFrom, unitTo parameters)
            double calculateValue = GetMultiplierStub(unitConvertFrom, unitConvertTo);
            double finalResult = calculateValue * value;

            return finalResult;
        }

        private static string ModifyInput(string input)
        {
            try
            {
                switch (input)
                {
                    case "Seconds":
                    case "seconds":
                    case "s":
                    case "S":
                        input = "seconds";
                        break;

                    case "minutes":
                    case "Minutes":
                    case "m":
                    case "M":
                        input = "minutes";
                        break;

                    case "hours":
                    case "Hours":
                    case "h":
                    case "H":
                        input = "hours";
                        break;

                    case "days":
                    case "Days":
                    case "d":
                    case "D":
                        input = "days";
                        break;

                    default:

                        Console.WriteLine("\nIncorrect time unit");
                        break;
                }
            }
            catch (ArgumentException)
            {
                Console.WriteLine("\nIncorrect time unit");
            }

            return input;
        }

        private static double GetMultiplierStub(string unitConvertFrom, string unitConvertTo)
        {
            double returnValue = 60d;
            
            return returnValue;
        }
    }
}
