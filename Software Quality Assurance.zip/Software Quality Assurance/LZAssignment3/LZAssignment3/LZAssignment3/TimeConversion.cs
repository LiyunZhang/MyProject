﻿/*Program.cs
 *  PROG2070
 *  Assignment 3 - TimeConversion.cs 
 *  Liyun Zhang, 2018.03.27: Created
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LZAssignment3
{
    public static class TimeConversion
    {       
        public static double Convert(double value, string unitConvertFrom, string unitConvertTo)
        {            
           
            unitConvertFrom = ModifyInput(unitConvertFrom);
            unitConvertTo = ModifyInput(unitConvertTo);

            Console.WriteLine("\nConvert from: " + unitConvertFrom);
            Console.WriteLine("\nConvert To:" + unitConvertTo);

            //should be called GetMultiplier Method using (unitFrom, unitTo parameters)
            double calculateValue = GetMultiplier(unitConvertFrom, unitConvertTo);
            double finalResult = calculateValue * value;

            return finalResult;
        }

        private static string ModifyInput(string input)
        {
            try
            {
                switch (input)
                {
                    case "Seconds":
                    case "seconds":
                    case "s":
                    case "S":
                        input = "seconds";
                        break;

                    case "minutes":
                    case "Minutes":
                    case "m":
                    case "M":
                        input = "minutes";
                        break;

                    case "hours":
                    case "Hours":
                    case "h":
                    case "H":
                        input = "hours";
                        break;

                    case "days":
                    case "Days":
                    case "d":
                    case "D":
                        input = "days";
                        break;

                    default:

                        Console.WriteLine("\nIncorrect time unit");
                        break;
                }
            }
            catch (ArgumentException)
            {
                Console.WriteLine("\nIncorrect time unit");
            }           

            return input;
        }

        private static double GetMultiplier(string unitConvertFrom, string unitConvertTo)
        {
            double returnValue = 0.0d;

            if (unitConvertFrom.Equals("seconds"))
            {               
                if (unitConvertTo.Equals("minutes"))
                {
                    returnValue = 1 / 60d;
                }
                if (unitConvertTo.Equals("hours"))
                {
                    returnValue = 1 / 3600d;
                }
                if (unitConvertTo.Equals("days"))
                {
                    returnValue = 1 / 86400d;
                }
            }
            if (unitConvertFrom.Equals("minutes"))
            {
                if (unitConvertTo.Equals("seconds"))
                {
                    returnValue = 60d;
                }
                if (unitConvertTo.Equals("hours"))
                {
                    returnValue = 1 / 60d;
                }
                if (unitConvertTo.Equals("days"))
                {
                    returnValue = 1 / 1440d;
                }
            }
            if (unitConvertFrom.Equals("hours"))
            {
                if (unitConvertTo.Equals("seconds"))
                {
                    returnValue = 3600d;
                }
                if (unitConvertTo.Equals("minutes"))
                {
                    returnValue = 60d;
                }
                if (unitConvertTo.Equals("days"))
                {
                    returnValue = 1 / 24d;
                }
            }
            if (unitConvertFrom.Equals("days"))
            {
                if (unitConvertTo.Equals("seconds"))
                {
                    returnValue = 86400d;
                }
                if (unitConvertTo.Equals("minutes"))
                {
                    returnValue = 1440d;
                }
                if (unitConvertTo.Equals("hours"))
                {
                    returnValue = 24d;
                }
            }


            return returnValue;
        }
    }
}
