﻿/*Program.cs
 *  PROG2070
 *  Assignment 3 - ProjectA - TimeConversion.cs 
 *  Liyun Zhang, 2018.03.29: Created
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectA
{
    public static class TimeConversion
    {
        public static double Convert(double value, string unitConvertFrom, string unitConvertTo)
        {

            unitConvertFrom = ModifyInputStub("seconds");
            unitConvertTo = ModifyInputStub("minutes");

            Console.WriteLine("\nConvert from: " + unitConvertFrom);
            Console.WriteLine("\nConvert To:" + unitConvertTo);

            //should be called GetMultiplier Method using (unitFrom, unitTo parameters)
            double calculateValue = GetMultiplierStub(unitConvertFrom, unitConvertTo);
            double finalResult = calculateValue * value;

            return finalResult;
        }

        private static string ModifyInputStub(string input)
        {
            return input;
        }

        private static double GetMultiplierStub(string unitConvertFrom, string unitConvertTo)
        {
            double returnValue = 0.0d;

            if (unitConvertFrom.Equals("seconds"))
            {
                if (unitConvertTo.Equals("minutes"))
                {
                    returnValue = 1 / 60d;
                }
                if (unitConvertTo.Equals("hours"))
                {
                    returnValue = 1 / 3600d;
                }
                if (unitConvertTo.Equals("days"))
                {
                    returnValue = 1 / 86400d;
                }
            }
            if (unitConvertFrom.Equals("minutes"))
            {
                if (unitConvertTo.Equals("seconds"))
                {
                    returnValue = 60d;
                }
                if (unitConvertTo.Equals("hours"))
                {
                    returnValue = 1 / 60d;
                }
                if (unitConvertTo.Equals("days"))
                {
                    returnValue = 1 / 1440d;
                }
            }
            if (unitConvertFrom.Equals("hours"))
            {
                if (unitConvertTo.Equals("seconds"))
                {
                    returnValue = 3600d;
                }
                if (unitConvertTo.Equals("minutes"))
                {
                    returnValue = 60d;
                }
                if (unitConvertTo.Equals("days"))
                {
                    returnValue = 1 / 24d;
                }
            }
            if (unitConvertFrom.Equals("days"))
            {
                if (unitConvertTo.Equals("seconds"))
                {
                    returnValue = 86400d;
                }
                if (unitConvertTo.Equals("minutes"))
                {
                    returnValue = 1440d;
                }
                if (unitConvertTo.Equals("hours"))
                {
                    returnValue = 24d;
                }
            }


            return returnValue;
        }
    }
}
