﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectA
{
    public class Program
    {
        static void Main(string[] args)
        {
            string userOption;
            string value;
            double dVal = 0;
            bool isNumeric = true;
            string unitConvertFrom, unitConvertTo;

            do
            {
                Console.WriteLine("\n       MENU\n");
                Console.WriteLine("1: Convert time");
                Console.WriteLine("2: Exit\n");

                userOption = Console.ReadLine();

                switch (userOption)
                {
                    case "1":
                        Console.Clear();

                        while (isNumeric)
                        {
                            Console.Write("Please enter a time: ");
                            value = Console.ReadLine();

                            if (!double.TryParse(value, out dVal))
                            {
                                Console.WriteLine("Invalid input, please try again");
                            }
                            else
                            {
                                isNumeric = false;
                            }
                        }

                        Console.Write("Please enter what the time unit is: ");
                        unitConvertFrom = Console.ReadLine();
                        Console.Write("Please enter what unit you wish to convert the time to: ");
                        unitConvertTo = Console.ReadLine();

                        Console.WriteLine("\nResult: " + TimeConversion.Convert(dVal, unitConvertFrom, unitConvertTo));

                        isNumeric = true;
                        break;

                    case "2":
                        Console.Clear();
                        System.Environment.Exit(1);
                        break;

                    default:
                        Console.WriteLine("\nIncorrect input, please choose one option again");
                        break;
                }
            }
            while (true);
        }
    }
}
