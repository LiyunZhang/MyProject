﻿/*Program.cs
 *  PROG2070
 *  Assignment 2 - TriangleSolverTest.cs 
 *  Liyun Zhang, 2018.02.22: Created
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Assignment2;

namespace Assignment2.Tests
{
    [TestFixture]
    public class TriangleSolverTest
    {
        [Test()]
        public static void TestAnalyze_1_1_0_fail()
        {
            var result = TriangleSolver.Analyze(1, 1, 0);
            Assert.AreEqual("Sorry! Those inputs can not form a triangle, please try again.", result);
        }
        [Test()]
        public static void TestAnalyze_11_1_2_fail()
        {
            var result = TriangleSolver.Analyze(11, 1, 2);
            Assert.AreEqual("Sorry! Those inputs can not form a triangle, please try again.", result);
        }
        [Test()]
        public static void TestAnalyze_2_2_2_equilateral()
        {
            var result = TriangleSolver.Analyze(2, 2, 2);
            Assert.AreEqual("This is an equilateral triangle.", result);
        }
        [Test()]
        public static void TestAnalyze_3_3_3_equilateral()
        {
            var result = TriangleSolver.Analyze(3, 3, 3);
            Assert.AreEqual("This is an equilateral triangle.", result);
        }
        [Test()]
        public static void TestAnalyze_2_2_3_isosceles()
        {
            var result = TriangleSolver.Analyze(2, 2, 3);
            Assert.AreEqual("This is an isosceles triangle.", result);
        }
        [Test()]
        public static void TestAnalyze_4_4_6_isosceles()
        {
            var result = TriangleSolver.Analyze(4, 4, 6);
            Assert.AreEqual("This is an isosceles triangle.", result);
        }
        [Test()]
        public static void TestAnalyze_3_4_5_scalene()
        {
            var result = TriangleSolver.Analyze(3, 4, 5);
            Assert.AreEqual("This is a scalene triangle.", result);
        }
        [Test()]
        public static void TestAnalyze_5_6_7_scalene()
        {
            var result = TriangleSolver.Analyze(5, 6, 7);
            Assert.AreEqual("This is a scalene triangle.", result);
        }
    }
}
