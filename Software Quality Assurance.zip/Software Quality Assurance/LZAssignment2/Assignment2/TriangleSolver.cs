﻿/*Program.cs
 *  PROG2070
 *  Assignment 2 - TriangleSolver.cs 
 *  Liyun Zhang, 2018.02.22: Created
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    public static class TriangleSolver
    {
        public static string Analyze(int a, int b, int c)
        {
            bool isValidTriangle = true;
            string result = "";

            if ((a + b > c) && (a + c > b) && (b + c > a)) // three inputs can form a triangle
            {
                Console.WriteLine("\nTriangle is valid.\n");

                if (isValidTriangle) // determine three types of triangle
                {
                    if(a==b && b==c)
                    {
                        result = "This is an equilateral triangle.";
                    }
                    else if(a==b || b==c || a == c)
                    {
                        result = "This is an isosceles triangle.";
                    }
                    else
                    {
                        result = "This is a scalene triangle.";
                    }
                }
            }
            else  // three inputs can not form a triangle
            {
                result = "Sorry! Those inputs can not form a triangle, please try again.";
                isValidTriangle = false;
            }

            return result;
        }
    }
}


