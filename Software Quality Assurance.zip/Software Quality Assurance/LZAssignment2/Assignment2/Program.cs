﻿/*Program.cs
 *  PROG2070
 *  Assignment 2 - Program.cs 
 *  Liyun Zhang, 2018.02.22: Created
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    public class Program
    {
        static void Main(string[] args)
        {
            string userOption;
            int a=0, b=0, c=0;

            try
            {

                do
                {   // show the menu and choose option

                    Console.WriteLine("\n  ********** MENU **********\n");
                    Console.WriteLine("1: Enter triangle dimensions");
                    Console.WriteLine("2: Exit\n");

                    userOption = Console.ReadLine();

                    switch (userOption)
                    {
                        case "1":
                            Console.Clear();

                            try
                            {
                                Console.Write("Please enter the first integer: ");
                                a = int.Parse(Console.ReadLine());
                                Console.Write("Please enter the second integer: ");
                                b = int.Parse(Console.ReadLine());
                                Console.Write("Please enter the third integer: ");
                                c = int.Parse(Console.ReadLine());
                            }
                            catch(Exception ex)
                            {
                                Console.WriteLine("Invalid input");
                                a = 0;
                                b = 0;
                                c = 0;
                                userOption = "1";
                            }

                            Console.WriteLine(TriangleSolver.Analyze(a, b, c));
                            break;

                        case "2":
                            Console.Clear();
                            System.Environment.Exit(1);
                            break;

                        default:
                            Console.WriteLine("\nIncorrect input, please choose one option again");
                            break;
                    }

                }
                while (true);
            }
            catch (Exception e)
            {
                Console.WriteLine("\nInvalid input, please run again.\n");
            }
        }
    }
}

