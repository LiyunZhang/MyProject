﻿/*
 * PROG2370 Assignment 4 (Pong game)
 * Liyun Zhang - Section 5
 * 2018.01.02
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Media;

namespace Pone_game
{
    class Paddle : DrawableGameComponent
    {
        public Texture2D texture;
        public Vector2 position;
        private SpriteBatch spriteBatch;
        private Vector2 speed;
        private Vector2 stage;

        private int playerNumber;
               

        public Paddle(Game game, 
                    Texture2D texture,
                    Vector2 position,
                    SpriteBatch spriteBatch,
                    Vector2 speed,
                    Vector2 stage,
                    int playerNumber) : base(game)
        {
            this.texture = texture;
            this.position = position;
            this.spriteBatch = spriteBatch;
            this.speed = speed;
            this.stage = stage;
            this.playerNumber = playerNumber;
        }

        // Update
        public override void Update(GameTime gameTime)
        {
            //player 1 moving by A and Z
            if(playerNumber == 1)
            {
                if (Keyboard.GetState().IsKeyDown(Keys.A))
                {
                    position -= speed;
                }
                else if (Keyboard.GetState().IsKeyDown(Keys.Z))
                {
                    position += speed;
                }
            }

            //player 2 moving by UP and DOWN
            if(playerNumber == 2)
            {
                if (Keyboard.GetState().IsKeyDown(Keys.Up))
                {
                    position -= speed;
                }
                else if (Keyboard.GetState().IsKeyDown(Keys.Down))
                {
                    position += speed;
                }
            }
                      
            //making a boundary for the moving paddle
            if(position.Y > stage.Y - texture.Height)
            {
                position.Y = stage.Y - texture.Height;
            }
            else if(position.Y < 0)
            {
                position.Y = 0;
            }

            base.Update(gameTime);

           
        }

        // Draw
        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(texture, position, Color.White);
            spriteBatch.End();

            base.Draw(gameTime);
        }

        public Rectangle getBound()
        {
            return new Rectangle((int)position.X, (int)position.Y, texture.Width, texture.Height);
        }
    }

}
