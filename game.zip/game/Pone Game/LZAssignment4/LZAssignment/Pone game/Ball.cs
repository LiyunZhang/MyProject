﻿/*
 * PROG2370 Assignment 4 (Pong game)
 * Liyun Zhang - Section 5
 * 2018.01.02
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Media;

namespace Pone_game
{
    class Ball : DrawableGameComponent
    {
        public Texture2D texture;
        public Vector2 position;
        private SpriteBatch spriteBatch;
        public Vector2 speed;
        private Vector2 stage;
        public bool ballEnable = false;

        public int p1Score = 0;
        public int p2Score = 0;

        public Vector2 ballSpeed;

        int posX = 0, posY = 0;


        // constructor for Ball
        public Ball(Game game,
                    Texture2D texture,
                    Vector2 position,
                    SpriteBatch spriteBatch,
                    Vector2 speed,
                    Vector2 stage
                    ) : base(game)
        {            
            this.texture = texture;
            this.position = position;
            this.spriteBatch = spriteBatch;
            this.speed = speed;
            this.stage = stage;
            ballEnable = false;           
        }

        // Update
        public override void Update(GameTime gameTime)
        {
            position += speed;

            //top
            if(position.Y <= 0)
            {
                //Random nSpd = new Random();
                //posX = nSpd.Next(3, 9);
                //posY = nSpd.Next(3, 9);
                //ballSpeed = new Vector2(posX, posY);
                //speed = ballSpeed;   

                speed.Y = -speed.Y;             
                Game1.dingSound.Play();
            }

            //right
            if(position.X >= stage.X)
            {
                p1Score++;
                Game1.clickSound.Play();
                this.Enabled = false;
            }

            //bottom
            if(position.Y + texture.Height >= stage.Y)
            {
                //Random nSpd = new Random();
                //posX = nSpd.Next(3, 9);
                //posY = nSpd.Next(3, 9);
                //speed = new Vector2(posX, posY);
                
                speed.Y = -speed.Y;

                //sound will be here
                Game1.dingSound.Play();
            }

            //left
            if(position.X + texture.Width <= 0)
            {
                p2Score++;
                Game1.clickSound.Play();
                this.Enabled = false;
            }

            base.Update(gameTime);
        }

        // Draw
        public override void Draw(GameTime gameTime)
        {            
            spriteBatch.Begin();
            spriteBatch.Draw(texture, position, Color.White);
            spriteBatch.End();

            base.Draw(gameTime);
        }

        public Rectangle getBound()
        {
            return new Rectangle((int)position.X, (int)position.Y, texture.Width, texture.Height);
        }
    }      
     
}

