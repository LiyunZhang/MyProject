﻿/*
 * PROG2370 Assignment 4 (Pong game)
 * Liyun Zhang - Section 5
 * 2018.01.02
 */ 
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Media;

namespace Pone_game
{

    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        SpriteFont Arial;

        Paddle p1;
        Paddle p2;
        Ball ball;

        // Sound
        public static SoundEffect dingSound;
        public static SoundEffect clickSound;
        public static SoundEffect applause1Sound;

        string Player1 = "Liyun #1";
        string Player2 = "Liyun #2";

        // Position
        Vector2 p1ScorePosition;
        Vector2 p2ScorePosition;
        Vector2 p1PaddlePosition;
        Vector2 p2PaddlePosition;
        Vector2 ballPosition;
        Vector2 ballSpeed;
        Vector2 stage;
        Vector2 originBallPosition;
        Vector2 originPaddlePositionA;
        Vector2 originPaddlePositionB;       


        public bool gameEnd = false;
        //for random speed
        int posX=0, posY=0;

        // Game1
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            graphics.IsFullScreen = false;
            graphics.PreferredBackBufferHeight = 600;
            graphics.PreferredBackBufferWidth = 900;

            Content.RootDirectory = "Content";
        }

        // Initialize
        protected override void Initialize()
        {
            this.IsMouseVisible = true;

            base.Initialize();
        }

        // Load Content
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            stage = new Vector2(graphics.PreferredBackBufferWidth, graphics.PreferredBackBufferHeight);

            //Textures      
            //

            // Sound
            dingSound = Content.Load<SoundEffect>("ding");
            clickSound = Content.Load<SoundEffect>("click");
            applause1Sound = Content.Load<SoundEffect>("applause1");

            //Fonts
            Arial = Content.Load<SpriteFont>("Arial");

            //Starting Score Font Position
            p1ScorePosition.X = 40;
            p1ScorePosition.Y = 30;
            p2ScorePosition.X = 730;
            p2ScorePosition.Y = 30;                   

            //ball
            Texture2D ballTex = this.Content.Load<Texture2D>("Ball");
            ballPosition = new Vector2((900 / 2) - ballTex.Width / 2, (600 / 2) - ballTex.Height / 2);
            originBallPosition = new Vector2((900 / 2) - ballTex.Width / 2, (600 / 2) - ballTex.Height / 2);
            
            ball = new Ball(this, ballTex, ballPosition, spriteBatch, ballSpeed, stage);
            this.Components.Add(ball);

            // Starting positions for paddles 1   
            Texture2D p1Tex = this.Content.Load<Texture2D>("BatLeft");            
            p1PaddlePosition = new Vector2(30, graphics.GraphicsDevice.Viewport.Height / 2 - (p1Tex.Height / 2));
            originPaddlePositionA = new Vector2(30, graphics.GraphicsDevice.Viewport.Height / 2 - (p1Tex.Height / 2));
            Vector2 paddle1Speed = new Vector2(0, 6); // Y speed of paddle 1
            p1 = new Paddle(this, p1Tex, p1PaddlePosition, spriteBatch, paddle1Speed, stage, 1);
            this.Components.Add(p1);

            // Starting positons for paddles 2
            Texture2D p2Tex = this.Content.Load<Texture2D>("BatRight");
            p2PaddlePosition = new Vector2(graphics.GraphicsDevice.Viewport.Width - 30 - (p2Tex.Width), graphics.GraphicsDevice.Viewport.Height / 2 - (p2Tex.Height / 2));
            originPaddlePositionB = new Vector2(graphics.GraphicsDevice.Viewport.Width - 30 - (p2Tex.Width), graphics.GraphicsDevice.Viewport.Height / 2 - (p2Tex.Height / 2));
            Vector2 paddle2Speed = new Vector2(0, 6); // Y speed of paddle 2
            p2 = new Paddle(this, p2Tex, p2PaddlePosition, spriteBatch, paddle2Speed, stage,2);
            this.Components.Add(p2);
        }

        // UnloadContent
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        //Update
        protected override void Update(GameTime gameTime)
        {
            // Esc program anytime
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

           
            //if game is still running
            if (ball.ballEnable == false && gameEnd == false)
            {
                // pressing the Enter, game will start
                if (Keyboard.GetState().IsKeyDown(Keys.Enter))
                {
                    ball.Enabled = true;

                    //get a random speed
                    Random nSpd = new Random();
                    posX = nSpd.Next(3, 9);
                    posY = nSpd.Next(3, 9);
                    ballSpeed = new Vector2(posX, posY);
                    ball.speed = ballSpeed;

                    ball.position = ballPosition;                    
                    p1.position = p1PaddlePosition;
                    p2.position = p2PaddlePosition;
                }
            }
            
            // if game is over
            if (gameEnd == true)
            {
                // put miss sounds here
                applause1Sound.Play();

                if (Keyboard.GetState().IsKeyDown(Keys.Space))
                {
                    ball.position = originBallPosition;
                    p1.position = originPaddlePositionA;
                    p2.position = originPaddlePositionB;
                    ball.p1Score = 0;
                    ball.p2Score = 0;
                    gameEnd = false;
                }
            }

            // if ball hit the paddle 
            // collision 
            if (ball.getBound().Intersects(p1.getBound()))
            {
                Random nSpd = new Random();
                posX = nSpd.Next(3, 9);
                posY = nSpd.Next(3, 9);
                ballSpeed = new Vector2(posX, posY);
                ball.speed = ballSpeed;

                dingSound.Play();
                ball.speed.X = Math.Abs(ball.speed.X);
            }
            if (ball.getBound().Intersects(p2.getBound()))
            {
                Random nSpd = new Random();
                posX = nSpd.Next(3, 9);
                posY = nSpd.Next(3, 9);
                ballSpeed = new Vector2(posX, posY);
                ball.speed = ballSpeed;

                dingSound.Play();
                ball.speed.X = -Math.Abs(ball.speed.X);
            }
                           
                base.Update(gameTime);
        }

        // Draw
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            spriteBatch.Begin();

            //Drawing and Showing the Scores
            spriteBatch.DrawString(Arial, Player1 + " : " + ball.p1Score.ToString(), p1ScorePosition, Color.Yellow);
            spriteBatch.DrawString(Arial, Player2 + " : " + ball.p2Score.ToString(), p2ScorePosition, Color.Yellow);

            if(ball.p1Score == 2)
            {
                spriteBatch.DrawString(Arial, Player1 + " WIN", new Vector2(stage.X / 2, stage.Y / 2), Color.White);
                //applause1Sound.Play(); // (put the sound into the Update)
                gameEnd = true;
            }
            if (ball.p2Score == 2)
            {
                spriteBatch.DrawString(Arial, Player2 + " WIN", new Vector2(stage.X / 2, stage.Y / 2), Color.White);
                //applause1Sound.Play(); // (put the sound into the Update)
                gameEnd = true;
            }

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
