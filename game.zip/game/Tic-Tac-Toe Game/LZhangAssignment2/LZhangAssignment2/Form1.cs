﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LZhangAssignment2
{
    public partial class Form1 : Form
    {
        // true = X turn, false = O turn
        bool turn = true;
        int turn_count = 0;

        public Form1()
        {
            InitializeComponent();
        }
        
        private void Button_Cick(object sender, EventArgs e)
        {
            Button b = (Button)sender;

            if (turn)
            {
                b.Text = "X";
            }
            else
                b.Text = "O";

            turn = !turn;
            b.Enabled = false;
            turn_count++;

            Check_For_Winner();
        }

        private void Check_For_Winner()
        {
            bool someoneWin = false;

            //All situaltions of win
            //  1|2|3            
            //  4|5|6
            //  7|8|9
            if ((b1.Text == b2.Text) && (b2.Text == b3.Text) &&(!b1.Enabled))//[1,2,3]
            {
                someoneWin = true;
            }
            else if ((b4.Text == b5.Text) && (b5.Text == b6.Text) && (!b4.Enabled))//[4,5,6]
            {
                someoneWin = true;
            }
            else if ((b7.Text == b8.Text) && (b8.Text == b9.Text) && (!b7.Enabled))//[7,8,9]
            {
                someoneWin = true;
            }
            else if ((b1.Text == b4.Text) && (b4.Text == b7.Text) && (!b1.Enabled))//[1,4,7]
            {
                someoneWin = true;
            }
            else if ((b2.Text == b5.Text) && (b5.Text == b8.Text) && (!b2.Enabled))//[2,5,8]
            {
                someoneWin = true;
            }
            else if ((b3.Text == b6.Text) && (b6.Text == b9.Text) && (!b3.Enabled))//[3,6,9]
            {
                someoneWin = true;
            }
            else if ((b1.Text == b5.Text) && (b5.Text == b9.Text) && (!b1.Enabled))//[1,5,9]
            {
                someoneWin = true;
            }
            else if ((b3.Text == b5.Text) && (b5.Text == b7.Text) && (!b3.Enabled))//[3,5,7]
            {
                someoneWin = true;
            }

            //Show the winner message
            if (someoneWin)
            {
                disableButtons();

                string winner = "";
                if (turn)
                {
                    winner = "O";
                }
                else
                    winner = "X";

                MessageBox.Show("'"+ winner + "'" + " Win!", "Congratulations");
            }

            else
            {
                if(turn_count == 9)
                {
                    MessageBox.Show(" Draw! Try again", "WOW");
                }
            }
            
        }

        //Disable all buttons when someone win
        private void disableButtons()
        {
            try
            {
                foreach (Control c in Controls)
                {
                    Button b = (Button)c;
                    b.Enabled = false;
                }
            }
            catch
            {}
        }

        //Play New game
        private void NewGame_Click(object sender, EventArgs e)
        {
            turn = true;
            turn_count = 0;

            try
            {
                foreach (Control c in Controls)
                {
                    Button b = (Button)c;
                    b.Enabled = true;
                    b.Text = "";
                }
            }
            catch
            { }
        }

        //Exit game
        private void ExitGame_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}


