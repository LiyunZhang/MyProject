﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
 * PROG2370-Sec5 Assignment 1
 *      (Airline Reservation System)
 *      Liyun Zhang
 *      2017,09,24
 */
namespace LZhangAssignment1
{
    public partial class Form1 : Form
    {
        string[,] setArray = new string[5, 3];
        string[] setWaitingList = new string[10];
        string errorMessage = "";
        int count = 0;

        public Form1()
        {
            InitializeComponent();
        }             

        /// <summary>
        /// button Show All
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnShowAll_Click(object sender, EventArgs e)
        {
            string list = "";

            for (int i = 0; i < setArray.GetLength(0); i++)
            {
                for (int j = 0; j <setArray.GetLength(1) ; j++)
                {
                    list +="[" + i +", "+ j + "] = " + setArray[i,j] + "\n";

                
                }
            }
            rtxtShowAll.Text = list;
        }

        /// <summary>
        /// Button Show Waiting List 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnShowWaitingList_Click(object sender, EventArgs e)
        {
            string waiting_list = "";

            for (int i = 0; i < setWaitingList.GetLength(0); i++)
            {
                waiting_list += "[" + i + "] =" + setWaitingList[i] + "\n";
            }
            rtxtShowWaitingList.Text = waiting_list;
        }       

        /// <summary>
        ///  Fill All
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnFillAll_Click(object sender, EventArgs e)
        {
            txtName.Text = "Liyun";

            for (int i = 0; i < setArray.GetLength(0); i++)
            {
                for (int j = 0; j < setArray.GetLength(1); j++)
                {
                    setArray[i, j] = txtName.Text;
                }
            }
        }
        
        /// <summary>
        /// Button Status
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnStatus_Click(object sender, EventArgs e)
        {
            int row = listBoxRow.SelectedIndex;
            int seat = listBoxSeat.SelectedIndex;            
            string seat_status = "";

            //choose the row and seat
            if (row == -1)
            {
                errorMessage +="Please choose a row \n";
                
            }
            if (seat == -1)
            {
                errorMessage += "Please choose a seat";
            }

            if (row == -1 || seat == -1)
            {
                MessageBox.Show(errorMessage);
            }            

            if (row != -1 && seat != -1)
            {
                if (setArray[row, seat] == "" || setArray[row, seat] == null)
                {
                    seat_status = "Available";
                }
                else
                {
                    seat_status = "Not Available";
                }
                txtStatus.Text = seat_status;
            }            
           
        }

        /// <summary>
        /// Buttoon Book
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnBook_Click(object sender, EventArgs e)
        {
            int row = listBoxRow.SelectedIndex;
            int seat = listBoxSeat.SelectedIndex;

            for (int i = 0; i < setArray.GetLength(0); i++)
            {
                for (int j = 0; j < setArray.GetLength(1); j++)
                {
                    if (setArray[i, j] == null || setArray[i, j] == "")
                    {
                        //choose the row and seat
                        if (row == -1)
                        {
                            errorMessage += "Please choose a row \n";

                        }
                        if (seat == -1)
                        {
                            errorMessage += "Please choose a seat";
                        }

                        if (row == -1 || seat == -1)
                        {
                            MessageBox.Show(errorMessage);
                        }

                        if (row != -1 && seat != -1)
                        {
                            if (txtName.Text == "")
                            {
                                errorMessage += "Please input a name \n";
                                MessageBox.Show(errorMessage);
                            }

                            else if (setArray[row, seat] == null)
                            {
                                setArray[row, seat] = txtName.Text;
                                MessageBox.Show("Seat [ " + row + ", " + seat + " ] is booked now");

                                count++;
                            }
                            else
                            {
                                errorMessage += "Seat is occupied, please choose another one \n";
                                MessageBox.Show(errorMessage);
                            }
                        }
                        break;
                    }
                    else if (setArray[i, j] != null || setArray[i, j] != "")
                    {
                        if (txtName.Text == null || txtName.Text == "")
                        {
                            errorMessage = "";
                            MessageBox.Show("input a vaild name");
                            break;
                        }

                        else
                        {
                            if (count < 10)
                            {
                                setWaitingList[count] = txtName.Text;
                                MessageBox.Show("Successfully added in waiting list");
                                count++;
                                break;
                            }
                            //if count is over 10
                            else
                            {
                                MessageBox.Show("waiting list is full");
                                break;
                            }
                        }
                    }
                }
                break;
            }
            
        }

        /// <summary>
        /// Button Cancel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            int row = listBoxRow.SelectedIndex;
            int seat = listBoxSeat.SelectedIndex;                       

            //choose the row and seat
            if (row == -1)
            {
                errorMessage += "Please choose a row \n";

            }
            if (seat == -1)
            {
                errorMessage += "Please choose a seat";
            }

            if (row == -1 || seat == -1)
            {
                MessageBox.Show(errorMessage);
            }
            
            if (row != -1 && seat != -1)
            {
                if (setArray[row, seat] != null && setArray[row, seat] != "")
                {
                    setArray[row, seat] = null;
                    MessageBox.Show("Seat [ " + row + ", " + seat + " ] is canceled");

                    // moveing from waiting list to book
                    if (setWaitingList[0] != "" || setWaitingList[0] != null)
                    {
                        setArray[row, seat] = setWaitingList[0];
                        MessageBox.Show("Moved the 1st person from waiting list to the cancelled seat");

                        for (int i = 0; i < setWaitingList.GetLength(0)-1; i++)
                        {
                            setWaitingList[i] = setWaitingList[i + 1];
                        }
                        count--;
                    }
                }
                else
                {
                    errorMessage += "Can't cancel an empty seat, please choose another one. \n";
                    MessageBox.Show(errorMessage);
                }
            }
        }

        /// <summary>
        /// Add to waiting list
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddToWaitingList_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < setArray.GetLength(0); i++)
            {
                for (int j = 0; j < setArray.GetLength(1); j++)
                {
                    if (setArray[i, j] == null || setArray[i, j] == "")
                    {
                        MessageBox.Show("There are still seats available, use BOOK to book");
                        break;
                    }
                    else if (setArray[i, j] != null || setArray[i, j] != "")
                    {
                        if (txtName.Text == null || txtName.Text == "")
                        {
                            errorMessage = "";
                            MessageBox.Show("input a vaild name");
                            break;
                        }

                        else
                        {
                            if (count < 10)
                            {
                                setWaitingList[count] = txtName.Text;
                                MessageBox.Show("Successfully added in waiting list");
                                count++;
                                break;
                            }
                            //if count is over 10
                            else
                            {
                                MessageBox.Show("waiting list is full");
                                break;
                            }
                        }
                    }
                }
                break;
            }
        }
    }
}


