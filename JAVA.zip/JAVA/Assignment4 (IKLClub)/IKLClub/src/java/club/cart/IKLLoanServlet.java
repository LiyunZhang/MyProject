/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package club.cart;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import club.business.Book;
import club.business.ECart;
import club.business.ELoan;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author isolomon0566
 */
public class IKLLoanServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        //Create a new servlet context object
        ServletContext context = this.getServletContext();  
        
        //load items from servlet context
        Object loanItems = context.getAttribute("loanItems");
        
        //loadItems(string) method If loanitems stored in the servlet context object is null 
        if (loanItems == null)
        {
            //prepare the full path
            String path = context.getRealPath("/WEB-INF/books.txt");
            
            //store the ArrayList of Book objects
            ArrayList<Book> newLoanItems = ELoan.loadItems(path);
            context.setAttribute("loanItems", newLoanItems);
        }
        
        //Forward the control to IKLELoan.jsp page.
        context
                .getRequestDispatcher("/IKLELoan.jsp")
                .forward(request, response);

    }
    
    
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
