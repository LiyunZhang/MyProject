/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package club.cart;

import java.io.IOException;
import java.io.PrintWriter;
import club.cart.IKLCartServlet;
import java.util.ArrayList;
import club.business.Book;
import club.business.ECart;
import club.business.ELoan;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author user
 */
public class IKLClearCartServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

         //Create a new servlet context object
        ServletContext context = this.getServletContext();

        //Access the loanitems
        Object loanItems = context.getAttribute("loanItems");
        
        //HttpSession session = request.getSession();
        //ECart cart = (ECart) session.getAttribute("cart");
        String code = request.getParameter("code");
        String quantity = request.getParameter("quantity");
         
         //Create/save a loan cart object 
        //(instantiated from ECart class) in the session object
        HttpSession session = request.getSession();
        ECart cart = (ECart) session.getAttribute("cartSession");

        cart.getItems();
        
        if(cart == null){
            cart = new ECart();
        }
        
        ArrayList<Book> cartitems = cart.getItems();
        
        //Add book back to QOH
        for(Book b : cartitems){
            ELoan.addToQOH(cartitems, b.getCode(), b.getQuantity());
        }
       
        //Session invalidate
        request.getSession().invalidate();
     
        //Forward the control to IKLECart.jsp page.
        context
                .getRequestDispatcher("/IKLECart.jsp")
                .forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
