/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package club.cart;

import java.io.IOException;
import java.io.PrintWriter;
import club.cart.IKLCartServlet;
import java.util.ArrayList;
import club.business.Book;
import club.business.ECart;
import club.business.ELoan;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author isolomon0566
 */
public class IKLCartServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //Create a new servlet context object
        ServletContext context = this.getServletContext();

        //Access the loanitems
        Object loanItems = context.getAttribute("loanItems");

        //Create/save a loan cart object 
        //(instantiated from ECart class) in the session object
        HttpSession session = request.getSession();
        ECart cart = (ECart) session.getAttribute("cartSession");

        //action and code peremeter
        String action = request.getParameter("action");
        String code = request.getParameter("code");
        int total = 0;

        //create new cart if empty
        if (cart == null) {
            cart = new ECart();
        }

        //if action is reserve 
        if (loanItems != null && action != null && code != null) {
            if (action.equals("reserve")) {
               
                Book book = ELoan.findItem((ArrayList<Book>) loanItems, code);
                
                if(book.getQuantity() != 0)
                {
                    cart.addItem(book);
                    ArrayList<Book> books = cart.getItems();
                          
                for(Book b : books)
                {
                    total += b.getQuantity();
                }
                
                session.setAttribute("cartSession", cart);
                session.setAttribute("total", total);
                
                ELoan.subtractFromQOH((ArrayList<Book>) loanItems, code, 1);
                request.getSession().setAttribute("loanItems", loanItems);
            }
          
        }   
            
        }

        //Forward the control to IKLECart.jsp page.
        context
                .getRequestDispatcher("/IKLECart.jsp")
                .forward(request, response);

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
