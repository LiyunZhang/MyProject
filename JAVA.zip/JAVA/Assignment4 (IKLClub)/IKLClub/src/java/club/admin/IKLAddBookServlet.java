package club.admin;

import club.data.BookIO;
import club.business.Book;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Khalid
 */
public class IKLAddBookServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String url = "";
        String message = null;
        ArrayList<Book> books = new ArrayList<Book>();
        Book book = new Book();

        ServletContext context = getServletContext();
        String path = context.getRealPath("/WEB-INF/books.txt");

        String action = request.getParameter("action");
        if (action == null) {
            action = "/IKLAddBook";
        }

//        if (action.equals("add")) {
//            url = "/IKLDisplayBooks";
//        } 
        else if (action.equals("add")) {
            String code = request.getParameter("code");
            String description = request.getParameter("description");
            String quantity = request.getParameter("quantity");

            
            //Validation
            if (code == null || code.isEmpty()) {
                message = "Book code is required.";
                url = "/IKLAddBook";
            }
            else if (description.length() < 2) {
                message = "Description must have at least 2 characters.";
                url = "/IKLAddBook";
            }
            else if (Integer.parseInt(quantity) <= 0) {
                message = "Quantity must be a positive number.";
                url = "/IKLAddBook";
            } 
            else {
                message = null;  
                
                book.setCode(code);
                book.setDescription(description);
                book.setQuantity(Integer.parseInt(quantity));
                
                BookIO.insert(book, path);
                url = "/IKLDisplayBooks";
            }
            books = BookIO.getBooks(path);

            request.setAttribute("book", book);
            request.setAttribute("books", books);
            request.setAttribute("message", message);
            //getServletContext().getRequestDispatcher(url).forward(request, response);
        }
        getServletContext().getRequestDispatcher(url).forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }
}
