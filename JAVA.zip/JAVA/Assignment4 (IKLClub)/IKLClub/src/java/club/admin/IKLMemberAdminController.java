/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package club.admin;

import club.business.Member;
import club.data.MemberDB;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Liyun Zhang
 */
public class IKLMemberAdminController extends HttpServlet {

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        
                
        String message = "";        
        String url = "/IKLDisplayMembers.jsp";
         
          // get current action
        String action = request.getParameter("action");
        if (action == null) {
            action = "displayMembers";  // default action
        }
        
        // perform action and set URL to appropriate page       
        if (action.equals("displayMembers")) {            
            // get list of members
            ArrayList<Member> members = MemberDB.selectMembers();
                      
            request.setAttribute("members", members);
            url = "/IKLDisplayMembers.jsp";
        } 
       // display one member 
        else if (action.equals("displayMember")) {
            // get member for specified email
            String emailAddress = request.getParameter("emailAddress");
            Member member = MemberDB.selectMember(emailAddress);
            session.setAttribute("member", member);
            url = "/IKLMember.jsp";
        }
        
        //Update member
        else if (action.equals("updateMember")) {
            // update member in database
            String fullName = request.getParameter("fullName");
            String emailAddress = request.getParameter("emailAddress");
            String phoneNumber = request.getParameter("phoneNumber");
            String programName = request.getParameter("programName");
            String yearLevel = request.getParameter("yearLevel");
            
            // get current member list and set as request attribute
            Member member = MemberDB.selectMember(emailAddress);
            
            if(member == null) {
                member = new Member();
            }
            
            member.setFullName(fullName);
            member.setEmailAddress(emailAddress);
            member.setPhoneNumber(phoneNumber);
            member.setProgramName(programName);
            member.setYearLevel(Integer.parseInt(yearLevel));
                        
            //Validate input
            if(member.isValid()) {
                //Check if email exist
                if(MemberDB.emailExists(emailAddress)) {
                    MemberDB.update(member);
                }
                else {
                    MemberDB.insert(member);
                }
                ArrayList<Member> members = MemberDB.selectMembers();            
                request.setAttribute("members", members); 
            }
            else {
                message = "Member information is not valid.<br>" +
                          "You must enter a valid name and email.";
                
                session.setAttribute("member", member);
               url = "/IKLMember.jsp";
            }
           
        }
        
//        else if(action.equals("deletingMember")){
//           
//            String emailAddress = request.getParameter("emailAddress");
//            Member member = MemberDB.selectMember(emailAddress);
//            url = "/IKLConfirmMemberDelete.jsp";
//        }
        
        //Delete member
        else if (action.equals("deletingMember")) {
            // get the member for the specified email
            String emailAddress = request.getParameter("emailAddress");
            Member member = MemberDB.selectMember(emailAddress);            
            request.setAttribute("member", member); 
            url = "/IKLConfirmMemberDelete.jsp";            
            
        }
        else if(action.equals("deleteMember")){
                // delete the member
                String emailAddress = request.getParameter("emailAddress");
                Member member = MemberDB.selectMember(emailAddress);
                
                MemberDB.delete(member);
                // get current list of member
                ArrayList<Member> members = MemberDB.selectMembers(); 
                request.setAttribute("members", members);   
                url = "/IKLDisplayMembers.jsp";
            }
        
        //Add member
        else if(action.equals("addMember")) {
            session.setAttribute("member", null);
            url = "/IKLMember.jsp";
        }

        session.setAttribute("message", message);
        
        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);
    }
    
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

   
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
